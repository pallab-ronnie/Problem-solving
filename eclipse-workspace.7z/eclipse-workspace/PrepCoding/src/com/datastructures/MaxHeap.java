package com.datastructures;

public class MaxHeap {
	
	private int[] theHeap;
	private int capacity;
	private int pos;
	
	public MaxHeap() {
		this.pos = 0;
		this.capacity = 10;
		theHeap = new int[capacity];
	}
	
	public void insert(int value) {
		if(pos == capacity) {
			//ensureCapacity();
		}
		else {
			theHeap[pos++] = value;
			
			int child = pos ;
			int parent = (child -1) / 2;
			
			while(theHeap[parent] < theHeap[child] && parent > 0) {
				int tmp = theHeap[parent];
				theHeap[parent] = theHeap[child];
				theHeap[child] = tmp;
				
				child = parent;
				parent = (child-1)  / 2;
			}
		}
	}
	
	public void print() {
		for(int i =1 ;i<pos ; i++) {
			System.out.println(theHeap[i] + ",");
		}
	}
}
