package com.prep;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class TestString {
	
	public static void main(String[] args) throws IOException {

		Scanner scanner = new Scanner(System.in);
		String s = scanner.nextLine();
		String input[] = s.split(",");
		String s1 = null;
		String s2 = null;
		int len = 0;
		s1 = input[0].trim();
		s2 = input[1].trim();
		
		int n1 = s1.length();
		int n2 = s2.length();
		
		System.out.println(s1);
		System.out.println(s2);
		int i = 0;
		int j = 0;
		while(i<n1 && j<n2) {
			if(s1.charAt(n1-i-1)!= s2.charAt(n2-j-1)) {
				break;
			}
			len ++;
			i++;
			j++;
		}
		if(len == 0) {
			System.out.println("NULL");
		}
		
		System.out.println(s1.substring(n1-len));
		
	}
	
}
