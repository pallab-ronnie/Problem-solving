package com.prep;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class TestStr2 {
	
	public static void main(String[] args) throws IOException {
		InputStreamReader reader = new InputStreamReader(System.in, StandardCharsets.UTF_8);
	    BufferedReader in = new BufferedReader(reader);
	    String line;
	    String input = null;
	    while ((line = in.readLine()) != null) {
	      getLongestSuffix(line);
	    }
	    
		
	}

	private static void getLongestSuffix(String s) {
		String input[] = s.split(",");
		String s1 = null;
		String s2 = null;
		int len = 0;
		s1 = input[0].trim();
		s2 = input[1].trim();
		
		int n1 = s1.length();
		int n2 = s2.length();
		
		int i = 0;
		int j = 0;
		while(i<n1 && j<n2) {
			if(s1.charAt(n1-i-1)!= s2.charAt(n2-j-1)) {
				break;
			}
			len ++;
			i++;
			j++;
		}
		if(len == 0) {
			System.out.println("NULL");
		}
		
		System.out.println(s1.substring(n1-len));
		
	}
	
}
