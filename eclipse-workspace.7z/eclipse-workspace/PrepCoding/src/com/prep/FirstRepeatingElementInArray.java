package com.prep;

import java.util.HashSet;
import java.util.Set;

public class FirstRepeatingElementInArray {
	
	public static void main(String[] args) {

		int arr[] = {10, 5, 3, 4, 3, 5, 6};
        printFirstRepeating(arr);
	}

	public static void printFirstRepeating(int[] arr) {
		
		int index = -1;
		Set<Integer> countSet = new HashSet<Integer>();
		
//		for(int i = 0; i<arr.length ; i++) {
//			if(countSet.contains(arr[i])) {
//				index = i;
//				break;
//			}
//			else {
//				countSet.add(arr[i]);
//			}
//		}
		
		for(int i = arr.length -1 ;i >=0 ;i--) {
			if(countSet.contains(arr[i])) {
				index = i;
			}
			else {
				countSet.add(arr[i]);
			}
		}
		System.out.println("First repeating element " + arr[index]);
		
	}
	
}
