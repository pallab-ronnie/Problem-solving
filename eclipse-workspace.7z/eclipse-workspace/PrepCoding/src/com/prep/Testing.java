package com.prep;




class A{
	
	static class C{
		
	}
	protected A() {
		
	}
}

class B extends A{
	
}
public class Testing {
	public  void main(String[] args) {
		System.out.println("Test");
		
	}
}
