package com.prep;



public class OracleTest extends Test{
	
	
	
	
	
	public static void main(String[] args) {
		String s = "Pallab";
		StringBuilder sa;
		String s1 = s.intern();
		System.out.println(s1 == s);
	}
	
}
