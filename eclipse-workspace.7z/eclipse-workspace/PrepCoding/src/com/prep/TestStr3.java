package com.prep;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class TestStr3 {
	
	public static void main(String[] args) throws IOException {
		InputStreamReader reader = new InputStreamReader(System.in, StandardCharsets.UTF_8);
	    BufferedReader in = new BufferedReader(reader);
	    String line;
	    while ((line = in.readLine()) != null) {
	      getModifiedString(line);
	    }
		
	}

	private static void getModifiedString(String line) {

		char[] arr = line.toCharArray();
		char[] result = new char[arr.length *2];
		int j = 0;
		for(int i = 0; i<arr.length-1 ; i++) {
			if(((arr[i] == '2') || (arr[i] == '4') ||(arr[i] == '6') ||(arr[i] == '8')) &&
				((arr[i+1] == '2') || (arr[i+1] == '4') ||(arr[i+1] == '6') ||(arr[i+1] == '8'))) {
				result[j++] = arr[i];
				result[j++] = '*';
				
			}
			else if((arr[i] %2 != 0) && (arr[i+1] %2 !=0)) {
				result[j++] = arr[i];
				result[j++] = '-';
				
			}
			else {
				result[j++] = arr[i];
			}
		}
		result[j++] = arr[arr.length-1];
		for(int i = 0;i<j;i++) {
			System.out.print(result[i]);
		}
	}
	
}
