package com.customthreadpool;

public class PoolThread extends Thread {
	
	private BlockingQueue queue;
	private boolean isStopped;
	
	public PoolThread(BlockingQueue queue) {
		this.queue = queue;
	}
	
	public void run() {
		while(!isStopped) {
			try {
				Runnable r = (Runnable)queue.deQueue();
				r.run();
			} catch(Exception e) {
				
			}
		}
	}
	
	public synchronized void doStop() {
		isStopped = true;
		this.interrupt();
	}
	
	public boolean isStopped() {
		return isStopped;
	}
}
