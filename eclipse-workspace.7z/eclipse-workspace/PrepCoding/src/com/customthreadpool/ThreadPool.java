package com.customthreadpool;

import java.util.ArrayList;
import java.util.List;

public class ThreadPool {
	
	private BlockingQueue taskQueue;
	private List<PoolThread> poolList = new ArrayList<PoolThread>();
	private boolean isStopped;
	
	public ThreadPool(int nThreads, int maxTaskInQueue) {
		taskQueue = new BlockingQueue(maxTaskInQueue);
		
		for(int i=0 ;i<nThreads; i++) {
			poolList.add(new PoolThread(taskQueue));
		}
		
		for(PoolThread pool : poolList) {
			pool.start();
		}
	}
	
	
	public synchronized void execute(Runnable r) throws Exception{
		if(isStopped) {
			throw new IllegalStateException();
		}
		this.taskQueue.enQueue(r);
	}
	
	public synchronized void stop() {
		isStopped = true;
		for(PoolThread p: poolList) {
			p.doStop();
		}
	}
}
