package com.customthreadpool.revision;

import java.util.LinkedList;
import java.util.Queue;

public class CustomThreadPool {
	
	private int nThreads;
	private Queue<Runnable> taskqueue;
	private PoolWorker[] poolThread;
	
	public CustomThreadPool(int nThreads) {
		taskqueue = new LinkedList<>();
		this.nThreads = nThreads;
		poolThread = new PoolWorker[nThreads];
		
		for(int i = 0;i<nThreads;i++) {
			poolThread[i]  = new PoolWorker();
			poolThread[i].start();
		}
	}
	
	public void execute(Runnable task) {
		synchronized (taskqueue) {
			taskqueue.add(task);
			taskqueue.notify();
		}
	}
	
	private class PoolWorker extends Thread{

		@Override
		public void run() {

			Runnable task;
			
			while(true) {
				synchronized (taskqueue) {
					while(taskqueue.isEmpty()) {
						try {
							taskqueue.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					task = taskqueue.poll();
				}
				try {
					task.run();
				}catch(Exception e) {
					
				}
			}
		}
		
	}
}
