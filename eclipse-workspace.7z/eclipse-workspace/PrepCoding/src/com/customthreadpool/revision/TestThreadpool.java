package com.customthreadpool.revision;

class Task implements Runnable{
	
	int num;
	public Task(int num) {
		this.num = num;
	}
	
	public void run() {
		System.out.println("Num is " + num);
	}
}

public class TestThreadpool {
	
	public static void main(String[] args) {
		CustomThreadPool tp = new CustomThreadPool(10);
		for(int i = 0; i<=5;i ++) {
			Task t = new Task(i);
			tp.execute(t);
		}
		
	}
	
}
