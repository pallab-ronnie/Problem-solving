package com.customthreadpool;

import java.util.LinkedList;
import java.util.List;

public class BlockingQueue {
	
	private List queue = new LinkedList();
	private int limit = 10;
	
	public BlockingQueue(int limit) {
		this.limit = limit;
	}
	
	public BlockingQueue() {
		
	}
	
	public synchronized void enQueue(Object item) throws InterruptedException{
		while(this.queue.size() == this.limit) {
			wait();
		}
		if(this.queue.isEmpty()) {
			notifyAll();
		}
		queue.add(item);
	}
	
	public synchronized Object deQueue() throws InterruptedException{
		while(this.queue.isEmpty()) {
			wait();
		}
		if(this.queue.size()==this.limit) {
			notifyAll();
		}
		return this.queue.remove(0);
	}
}
