package com.cyclicbarrier;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class CabService implements Runnable {

	private CyclicBarrier cb ;
	
	public CabService(CyclicBarrier cb) {
		this.cb = cb;
	}
	
	@Override
	public void run() {

		System.out.println(Thread.currentThread().getName() + " has arrived");
		try {
			cb.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BrokenBarrierException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(Thread.currentThread().getName() + " is going to board the cab");
	}
	
}
