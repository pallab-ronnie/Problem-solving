package com.hashmaptest;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class HashMapTest {
	
	public static void main(String[] args) {

		Map<Emp, Integer> mapTest = new HashMap<Emp, Integer>();
		Emp e1 = new Emp(1, "Test1");
		Emp e2 = new Emp(1, "Test1");
		Emp e3 = new Emp(5, "Test2");
		
		mapTest.put(e1, 10);
		mapTest.put(e2, 10);	
		mapTest.put(e3 , 100);
		
		
		//System.out.println(mapTest.get(e2));
		
		
		for(Map.Entry<Emp, Integer> entry : mapTest.entrySet()) {
			//System.out.println(entry.getKey().getId());
		}
		
		
		Map<String, Integer> testConMap = new HashMap<>();
		testConMap.put("one", 1);
		testConMap.put("two", 2);
		testConMap.put("three", 3);
		testConMap.put("four", 4);
		testConMap.put("five", 5);
		testConMap.put("six", 6);
		
		Iterator<String> itr = testConMap.keySet().iterator();
		while(itr.hasNext()) {
			String key = itr.next();
			if(key.equals("three")) {
				testConMap.put(key+"new", 7);
			}
			System.out.println(key);
		}
	}
	
}
 