package com.singleton;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationBreaksSingleton {

	public static void main(String[] args) {

		Singleton instance1 = Singleton.getInstance();
		try {
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("file.ser"));
			objectOutputStream.writeObject(instance1);
			objectOutputStream.close();

			//Deserialize
			ObjectInputStream in 
			= new ObjectInputStream(new FileInputStream("file.ser"));
			Singleton instance2 = (Singleton) in.readObject();
			in.close();
			
			 System.out.println("instance1 hashCode:- "
                     + instance1.hashCode());
System.out.println("instance2 hashCode:- "
                     + instance2.hashCode());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
