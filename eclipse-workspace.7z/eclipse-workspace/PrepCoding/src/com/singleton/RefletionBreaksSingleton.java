package com.singleton;

import java.lang.reflect.Constructor;

public class RefletionBreaksSingleton {

	public static void main(String[] args) {

		Singleton instance1 = Singleton.getInstance();
		Singleton instance2 = null;
		
		try {
			Constructor[] constructors = Singleton.class.getDeclaredConstructors();
			for(Constructor c : constructors) {
				c.setAccessible(true);
				instance2 = (Singleton)c.newInstance();
				break;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Instance 1 hashcode " + instance1.hashCode());
		System.out.println("Instance 2 hashcode " + instance2.hashCode());
		
	}

}
