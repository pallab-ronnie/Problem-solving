package com.reentrantlock;

import java.util.Scanner;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Runner {
	
	private int count;
	private Lock lock = new ReentrantLock();
	private Condition cond = lock.newCondition();
	
	public void increment() {
		for (int i=1;i<=10000;i++) {
			count++;
		}
	}
	
	public void firstThread() throws InterruptedException{
		lock.lock();
		cond.await();
		
		System.out.println("woken up");
		try {
			increment();
		} finally {
			lock.unlock();
		}
	}
	
	public void secondThread() throws InterruptedException{
		Thread.sleep(3000);
		lock.lock();
		
		System.out.println("Press enter!");
		new Scanner(System.in).nextLine();
		System.out.println("Got enter");
		
		cond.signal();
		try {
			increment();
		} finally {
			lock.unlock();
		}
	}
	
	public void finished() {
		System.out.println("Count is: " + count);
	}
}
