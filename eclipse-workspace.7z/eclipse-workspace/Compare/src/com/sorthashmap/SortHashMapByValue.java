package com.sorthashmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.List;

public class SortHashMapByValue {

	public static void main(String[] args) {
		
		Map<String, Integer> map1 = new HashMap<>();
		map1.put("Pallab", 28);
		map1.put("Raja", 32);
		map1.put("Mota", 17);
		map1.put("Koushik", 2);
		map1.put("Test", 88);
		map1.put("Passed", 77);
		
		Set<Map.Entry<String, Integer>> entrySet = map1.entrySet();
		List<Map.Entry<String, Integer>> list = new ArrayList<>(map1.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {

			@Override
			public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
				return o1.getValue().compareTo(o2.getValue());
			}
		});
		
		for(Map.Entry<String, Integer> entry : list) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
	}

}
