package com.streams;

import java.util.Arrays;
import java.util.List;

import org.omg.Messaging.SyncScopeHelper;


public class StreamExample {
	public static void main(String[] args) {
		List<Person> people = Arrays.asList(
				new Person("Chrles" , "Dickens" ,60),
				new Person("Lewis", "Carroll",42),
				new Person("Thomas" , "Carlyle",51),
				new Person("Charlotte", "Bronte" ,45),
				new Person("Matthew" ,"Arnold",39)
				
				);
		
		System.out.println(people.stream()
		.findFirst());
		
		people.stream()
		.filter(p -> p.getLastName().startsWith("C"))
		.forEach(p -> System.out.println(p));
		
		people.stream()
		.filter(p -> p.getLastName().startsWith("C"))
		.count();
		
		Arrays.stream(new int[] {1,2,3,4,5}).filter(p -> p >= 3).map(p -> p*p).sorted().forEach(p -> System.out.println(p));
		
		List<Integer> testList = Arrays.asList(1,2,3,4,5);
		System.out.println("Result" + testList.stream().map(i -> i*2).reduce(0, (c,e) -> c+e));
		
		
		List<Integer> values = Arrays.asList(10,20,30,40,50);
		System.out.println(values.stream().filter(i -> i%5 ==0).map(i-> i*2).findFirst().orElse(0));
	}
}
