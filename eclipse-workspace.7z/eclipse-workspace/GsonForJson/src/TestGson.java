import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class TestGson {

	public static void main(String[] args) {

		//Java from JSON
		Gson gson = new Gson();
		GsonBuilder builder = new GsonBuilder();
		Gson gson1 = builder.create();
		String json = "{\"brand\":\"Jeep\", \"doors\": 3}";
		Car car = gson.fromJson(json, Car.class);		
		System.out.println(car.getBrand());
		
		//JSON from JAVA
		car = new Car();
		car.setBrand("Toyota");
		car.setDoors(4);
		gson = builder.setPrettyPrinting().create();
		String gsonString = gson.toJson(car);
		System.out.println("JSON " + gsonString); 
		
		
		JsonParser parser = new JsonParser();
		json = "{ \"f1\":\"Hello\",\"f2\":{\"f3:\":\"World\"}}";
		JsonElement jsonTree = parser.parse(json);
		JsonObject jsonObject = null;
		if(jsonTree.isJsonObject()) {
			 jsonObject = jsonTree.getAsJsonObject();
		}
		JsonElement f1 = jsonObject.get("f1");
		System.out.println(f1.toString());
	}

}
