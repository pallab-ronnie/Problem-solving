
public class Car {
	private transient String brand;
	
	private int doors;
	

	public String getBrand() {
		return brand;
	}

	public int getDoors() {
		return doors;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public void setDoors(int doors) {
		this.doors = doors;
	}
	
	
}
