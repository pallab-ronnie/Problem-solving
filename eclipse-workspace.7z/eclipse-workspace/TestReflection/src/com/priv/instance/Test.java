package com.priv.instance;

public class Test {

	private String s = "Pallab";
	
	
}
