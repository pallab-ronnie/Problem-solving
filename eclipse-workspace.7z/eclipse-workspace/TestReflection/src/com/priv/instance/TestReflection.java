package com.priv.instance;

import java.lang.reflect.Field;

public class TestReflection {

	public static void main(String[] args) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {
		Class c =  Test.class;
//		try {
//			Field fields = c.getField("s");
//			fields.setAccessible(true);
//			System.out.println(fields.toString());
//		} catch (NoSuchFieldException | SecurityException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		Field[] fields = c.getDeclaredFields();
		for(Field f : fields) {
			f.getName().toString();
			System.out.println(f.getName().toString());
			f.setAccessible(true);
			Test obj = new Test();
			Object val = f.get(obj);
			System.out.println(val.toString());
		}
		
		
		Field f = c.getDeclaredField("s");
		f.setAccessible(true);
		Test obj = new Test();
		Object val = f.get(obj);
		System.out.println(val.toString());
		
		
	}
}
