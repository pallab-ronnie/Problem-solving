package test;

public class Test {
	
	public static void main(String[] args) {

		int a = 11;
		int b = 3;
		double c = (double)a/b;
		int d = (int)Math.ceil(c);
		System.out.println(d);
	}
	
}
