package test;

import java.util.Arrays;
import java.util.Scanner;

public class Solution {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int t = sc.nextInt();
		for(int i=1; i<=t;i++) {
			int n = sc.nextInt();
			int s = sc.nextInt();
			int arr[] = new int[n];
			for(int j = 0; j<n ;j++) {
				arr[j] = sc.nextInt(); 
			}
			System.out.println(getDownloadTime(arr,n,s));
		}
	}

	private static int getDownloadTime(int[] arr, int n, int s) {

		int totalTime = 0;
		int len = n;
		Arrays.sort(arr);
		int i = 0;
		while(i<n) {
			int speed = (int) Math.floor(s / len);
			double t = (double)arr[i]/speed;
			int time = (int)Math.ceil(t);
			totalTime += time;
			int diff = arr[i];
			for(int j = i;j<n;j++) {
				arr[j] = arr[j] - diff;
			}
			for(int j = i;j<n ;j++) {
				if(arr[j] > 0) {
					i = j;
					len = n - i ;
					break;
				} else {
					i = n;
				}
			}
		}
		
		return totalTime;
	}
}
