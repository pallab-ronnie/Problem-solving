package com.practice.enumdemo;

//Behind the scenes
//class Mobile{
//	static final Mobile APPLE = new Mobile();
//	static final Mobile SAMSUNG = new Mobile();
//	static final Mobile HTC = new Mobile();
//}

enum Mobile{
	APPLE(100), SAMSUNG, HTC(90);
	
	int price;
	
	Mobile(){
		this.price = 80;
		System.out.println("Constructor");
	}
	
	Mobile(int price){
		this.price = price;
	}
	
	public int getPrice() {
		return this.price;
	}
}

public class EnumExample {

	public static void main(String[] args) {

		Mobile m = Mobile.APPLE;
		System.out.println(m.getPrice());
		switch(m) {
		case APPLE:
			System.out.println("Apple phone");
			break;
		case SAMSUNG:
			System.out.println("Samsung Phone");
			break;
		}
		
		Mobile mobileArray[] = Mobile.values();
		for(Mobile mobile: mobileArray) {
			System.out.println(mobile);
		}
	}

}
