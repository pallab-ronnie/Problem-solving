package com.practice.enumrevisited;

public class ColorTest {
	
	public static void main(String[] args) {

		Color c  = Color.RED;
		System.out.println("My color is " + c);
		System.out.println("My color rgb value " + c.rgbValue());
		
		
		Color[] colorArr = Color.values();
		for(Color color: colorArr) {
			System.out.println(color);
		}
	}
	
}
