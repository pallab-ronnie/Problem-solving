package com.practice.enumrevisited;

public enum Color {
	
	RED(255,0,0), GREEN(0,255,0), YELLOW(255,255,0), BLACK(0,0,0);
	
	private int red;
	private int green;
	private int blue;
	
	private Color(int red, int green, int blue) {
		this.red = red;
		this.green = green;
		this.blue = blue;
	}
	
	public String rgbValue() {
		return "(" + this.red + "," + this.green + "," + this.blue + ")";
	}
	
	@Override
	public String toString() {
		String color = super.toString();
		return color.substring(0,1) + color.substring(1).toLowerCase();
	}
	
}
