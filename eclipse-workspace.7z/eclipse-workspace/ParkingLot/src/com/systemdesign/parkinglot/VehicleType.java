package com.systemdesign.parkinglot;

public enum VehicleType {

	TWO_WHEELER,
	FOUR_WHEELER
}
