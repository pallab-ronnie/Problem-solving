package com.systemdesign.parkinglot;

public class Billing {

	
	public int generateBill(int totalTime, VehicleType type) {
		//logic 
		return 0;
	}
}
