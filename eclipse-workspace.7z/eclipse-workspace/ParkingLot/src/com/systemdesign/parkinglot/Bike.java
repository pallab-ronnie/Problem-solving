package com.systemdesign.parkinglot;

public class Bike extends Vehicle {

	@Override
	public void setVehicleType() {

		super.type = VehicleType.TWO_WHEELER;
	}
	
	
	
	
	
	
}
