package com.systemdesign.parkinglot;

import java.util.Date;

public class ParkingSpot {

	private int spotNum;
	private boolean isVacant;
	private Vehicle vehicle;
	private VehicleType type;
	private Date inTime;
	
	public Date getInTime() {
		return inTime;
	}

	public void setInTime(Date inTime) {
		this.inTime = inTime;
	}


	public ParkingSpot(int spotNum, boolean isVacant, Vehicle vehicle, VehicleType type) {
		super();
		this.spotNum = spotNum;
		this.isVacant = isVacant;
		this.vehicle = vehicle;
		this.type = type;
	}

	public int getSpotNum() {
		return spotNum;
	}

	public boolean isVacant() {
		return isVacant;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public VehicleType getType() {
		return type;
	}
	
	
}
