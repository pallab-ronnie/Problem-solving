package com.systemdesign.parkinglot;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ParkingLot {

	List<ParkingSpot> bikeParkingSpot = new ArrayList<>();
	List<ParkingSpot> carParkingSpot = new ArrayList<>();
	int maxSpot = 100;
	Billing b = new Billing();
	
	public ParkingSpot parkVehicle(Vehicle vehicle) {
		ParkingSpot spot = null ;
		if(vehicle.getType().equals(VehicleType.FOUR_WHEELER)) {
			if(carParkingSpot.size()<100) {
				spot = new ParkingSpot(carParkingSpot.size()*2 + 1, true, vehicle, VehicleType.FOUR_WHEELER);
				spot.setInTime(new Date(System.currentTimeMillis()));
				carParkingSpot.add(spot);
			}
		}
		else {
			if(bikeParkingSpot.size()<100) {
				spot = new ParkingSpot(1, true, vehicle, VehicleType.TWO_WHEELER);
				bikeParkingSpot.add(spot);
			}
		}
		return spot;
	}
	
	public ParkingSpot removeVehicle(Vehicle vehicle) {
		if(vehicle.getType().equals(VehicleType.FOUR_WHEELER)) {
			for(ParkingSpot p : carParkingSpot) {
				if(p.getVehicle().equals(vehicle)) {
					int totalTime = new Date(System.currentTimeMillis()).getHours() - p.getInTime().getHours();
					b.generateBill(totalTime, vehicle.getType());
					carParkingSpot.remove(p);
					return p;
				}
			}
		}
		return null;
	}
}
