package com.systemdesign.parkinglot;

public abstract class Vehicle {

	private String licensePlate;
	private String color;
	protected VehicleType type;
	public String getLicensePlate() {
		return licensePlate;
	}
	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	public abstract void setVehicleType();
	
	public VehicleType getType() {
		return type;
	}
	
}
