package com.systemdesign.parkinglot;

public class Car extends Vehicle {

	@Override
	public void setVehicleType() {

		super.type = VehicleType.FOUR_WHEELER;
	}
	
	

}
