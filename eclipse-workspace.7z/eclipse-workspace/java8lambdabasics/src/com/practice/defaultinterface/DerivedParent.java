package com.practice.defaultinterface;

public class DerivedParent {

	int x = 10;
}
