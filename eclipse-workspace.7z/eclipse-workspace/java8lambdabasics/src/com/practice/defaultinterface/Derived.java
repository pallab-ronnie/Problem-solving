package com.practice.defaultinterface;

public class Derived extends DerivedParent implements A,B{



	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void show() {
		String s = super.toString();
		A.super.show();
		System.out.println(super.x);
		System.out.println(this.getClass().getSuperclass());
	}

	public static void main(String[] args) {
		Derived d = new Derived();
		d.show();
		System.out.println(d.getClass());
	
	}
}
