package com.practice.defaultinterface;

public interface B {

	void display();
	
	default void show() {
		System.out.println("This is B");
	}
}
