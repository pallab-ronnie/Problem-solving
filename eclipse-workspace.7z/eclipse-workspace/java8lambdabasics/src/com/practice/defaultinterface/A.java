package com.practice.defaultinterface;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public interface A {

	void display();
	
	default void show() {
		System.out.println("This is A");
	}
}
