package com.practice.lambda;

public interface Greeting {

	public void perform();
}
