package com.practice.lambda;

public class RunnableExample {

	public static void main(String[] args) {
		Object o;
		Thread myThread = new Thread(new Runnable() {

			@Override
			public void run() {
				System.out.println("Inside runnable");

			}

		});
		myThread.start();

		Thread myLambdaThread = new Thread(()-> System.out.println("Inside Lambda thread"));
		myLambdaThread.start();
		
	}

}
