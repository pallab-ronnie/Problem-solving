package com.adapter;


public interface Pen {

	void write(String str);
}
