package com.abstractfactory;

public interface Animal {
	
	public String speak();
}
