package com.abstractfactory;

public class AbstractFactoryClient {

	public static void main(String[] args) {
		
		Animal animal = null;
		AnimalFactory animalFactory = null;
		String speakSound = null;
		
		//Get Factory object by passing the factory type
		animalFactory = AnimalFactory.getAnimalFactory("sea");
		System.out.println("Animal Factory type " + animalFactory.getClass().getName());
		
		//Get animal object by passing the animal type
		animal = animalFactory.getAnimal("shark");
		System.out.println("Animal type " + animal.getClass().getName());
		speakSound = animal.speak();
		System.out.println("Speak sound : " + speakSound);

	}

}
