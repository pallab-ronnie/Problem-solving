package com.abstractfactory;

public class Dog implements Animal {

	@Override
	public String speak() {
		return "Bark Bark Bark";

	}

}
