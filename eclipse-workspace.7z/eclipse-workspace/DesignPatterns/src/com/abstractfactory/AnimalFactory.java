package com.abstractfactory;

public abstract class AnimalFactory {

	public abstract Animal getAnimal(String animalType);
	
	public static AnimalFactory getAnimalFactory(String animalType) {
		AnimalFactory animalFactory = null;
		
		if ("sea".equalsIgnoreCase(animalType)) {
			animalFactory = new SeaAnimalFactory();
		}
		else {
			animalFactory = new LandAnimalFactory();
		}
		
		return animalFactory;
	}
}
