package com.abstractfactory;

public class Cat implements Animal {

	@Override
	public String speak() {
		return "Meow Meow Meow";

	}

}
