package com.abstractfactory;

public class Octopus implements Animal {

	@Override
	public String speak() {
		return "SQUAWCK";

	}

}
