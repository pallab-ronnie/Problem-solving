package com.abstractfactory;

public class Shark implements Animal {

	@Override
	public String speak() {
		return "Cannot speak";

	}

}
