package com.factory;

public class ComputerClient {

	public static void main(String[] args) {

		Computer pc = ComputerFactory.getComputer("pc", "2 GB", "500 GB", "2.4 Ghz");
		
		System.out.println(pc.toString());
	}

}
