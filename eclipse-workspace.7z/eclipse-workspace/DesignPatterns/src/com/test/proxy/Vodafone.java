package com.test.proxy;

public class Vodafone implements ISP {

	public String getResource(String site) {
		switch(site) {
		case "www.google.com":
			return "GOOOOOOGLEEE";
		case "www.yahoo.com":
			return "YAHooooooooooo";
		default:
			return "Sorry no resources found";
		}
			
		
	}

}
