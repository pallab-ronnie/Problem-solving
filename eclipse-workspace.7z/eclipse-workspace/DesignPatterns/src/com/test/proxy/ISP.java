package com.test.proxy;

public interface ISP {

	String getResource(String site);
}
