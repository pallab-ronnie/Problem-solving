package com.test.proxy;

public class InternetProxy implements ISP {

	@Override
	public String getResource(String site) {
		this.logRequest(site);
		if(isBlocked(site)) {
			return "This site is blocked as per the company policy.";
		}
		NetworkSettings networkSettings = new NetworkSettings();
		return networkSettings.getISP().getResource(site);
	}

	private void logRequest(String site) {

		System.out.println("Requested site " + site);
	}
	
	private boolean isBlocked(String site) {
		switch(site) {
		case "www.google.com":
			return false;
		case "www.gaming.com":
			return false;
		default:
			return false;
		}
	}

}
