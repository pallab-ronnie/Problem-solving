package com.singleton;

public enum EnumSingleton {
	
	INSTANCE;
}
