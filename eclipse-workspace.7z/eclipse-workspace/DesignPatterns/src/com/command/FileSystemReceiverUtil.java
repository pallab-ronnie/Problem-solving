package com.command;

public class FileSystemReceiverUtil {
	
	public static FileSystemReceiver getFileSystemReceiver() {
		String osName = System.getProperty("os.name");
		System.out.println("OS name : " + osName);
		if(osName.contains("Windows")) {
			return new WindowsFileSystemReceiver();
		}
		else {
			return new UnixFileSystemReceiver();
		}
	}
}
