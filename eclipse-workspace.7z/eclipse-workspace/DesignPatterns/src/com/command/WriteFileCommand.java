package com.command;

public class WriteFileCommand implements Command {

	private FileSystemReceiver fileSyestemReceiver;
	
	public WriteFileCommand(FileSystemReceiver fileSyestemReceiver) {
		this.fileSyestemReceiver = fileSyestemReceiver;
	}
	@Override
	public void execute() {
		this.fileSyestemReceiver.writeFile();
	}

}
