package com.command;

public interface Command {
	void execute();
}
