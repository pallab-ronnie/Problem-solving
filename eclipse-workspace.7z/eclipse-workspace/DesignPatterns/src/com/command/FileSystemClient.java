package com.command;

public class FileSystemClient {

	public static void main(String[] args) {

		FileSystemReceiver fileSystemReceiver = FileSystemReceiverUtil.getFileSystemReceiver();
		
		OpenFileCommand openFileCommand = new OpenFileCommand(fileSystemReceiver);
		
		FileInvoker fileInvoker = new FileInvoker(openFileCommand);
		
		fileInvoker.execute();
	}

}
