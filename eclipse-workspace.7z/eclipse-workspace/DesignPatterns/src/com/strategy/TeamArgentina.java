package com.strategy;

public class TeamArgentina extends Team {
	
	@Override
	public void teamInfo() {

		System.out.println("Argentina football team.");
	}
	
}
