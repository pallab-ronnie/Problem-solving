package com.strategy;

public abstract class Team {
	
	private String team;
	
	private TeamStrategy teamStrategy;

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public TeamStrategy getTeamStrategy() {
		return teamStrategy;
	}

	public void setTeamStrategy(TeamStrategy teamStrategy) {
		this.teamStrategy = teamStrategy;
	}
	
	public abstract void teamInfo();
	
	public void playGame() {
		teamStrategy.play(team);
	}
}
