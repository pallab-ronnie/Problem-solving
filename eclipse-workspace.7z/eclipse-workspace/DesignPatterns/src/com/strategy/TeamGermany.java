package com.strategy;

public class TeamGermany extends Team {
	
	@Override
	public void teamInfo() {

		System.out.println("German football team.");
	}
	
}
