package com.strategy;

public interface TeamStrategy {
	
	public void play(String team);
}
