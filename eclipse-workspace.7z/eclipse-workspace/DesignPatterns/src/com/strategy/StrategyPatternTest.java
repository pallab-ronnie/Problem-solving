package com.strategy;

public class StrategyPatternTest {
	
	public static void main(String[] args) {

		Team teamGermany = new TeamGermany();
		Team teamArgentina = new TeamArgentina();
		
		TeamStrategy attackStrategy = new AttackStrategy();
		TeamStrategy defendStrategy = new DefendStrategy();
		
		teamGermany.setTeamStrategy(defendStrategy);
		teamArgentina.setTeamStrategy(attackStrategy);
		
		teamGermany.setTeam("Germany");
		teamArgentina.setTeam("Argentina");
		
		teamGermany.teamInfo();
		teamGermany.playGame();
		
		teamArgentina.teamInfo();
		teamArgentina.playGame();
		
		System.out.println("After half time");
		
		teamGermany.setTeamStrategy(attackStrategy);
		teamArgentina.setTeamStrategy(defendStrategy);
		

		teamGermany.setTeam("Germany");
		teamArgentina.setTeam("Argentina");
		
		teamGermany.teamInfo();
		teamGermany.playGame();
		
		teamArgentina.teamInfo();
		teamArgentina.playGame();
	}
	
}
