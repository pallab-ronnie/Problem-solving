package com.observer;

public interface Observer {
	
	public void update(String productName);
}
