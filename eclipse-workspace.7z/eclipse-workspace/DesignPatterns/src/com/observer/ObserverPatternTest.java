package com.observer;

public class ObserverPatternTest {
	
	public static void main(String[] args) {

		Customer cust1 = new Customer();
		cust1.setCustomerName("Dinesh");
		
		Customer cust2 = new Customer();
		cust2.setCustomerName("Vijay");
		
		Product product = new Product();
		product.setProductName("Iphone 8");
		product.setAvailable(false);
		
		product.registerObserver(cust1);
		product.registerObserver(cust2);
		
		//After few days 
		
		product.setAvailable(true);
		
		product.removeObserver(cust2);
		product.setAvailable(true);
	}
	
}
