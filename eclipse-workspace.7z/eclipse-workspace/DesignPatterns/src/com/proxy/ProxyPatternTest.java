package com.proxy;

public class ProxyPatternTest {

	public static void main(String[] args) {

		CommandExecutor commandExecutor = new CommandExecutorProxy("Pallab", "pallab");
		try {
			commandExecutor.runCommand("ls -lrt");
			commandExecutor.runCommand("rm -rf");
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
