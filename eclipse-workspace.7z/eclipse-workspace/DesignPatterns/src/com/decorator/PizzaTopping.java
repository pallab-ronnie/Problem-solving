package com.decorator;

public abstract class PizzaTopping implements Pizza {
	
	Pizza pizza;
}
