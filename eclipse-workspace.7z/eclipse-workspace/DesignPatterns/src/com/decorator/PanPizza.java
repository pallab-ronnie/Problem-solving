package com.decorator;

public class PanPizza implements Pizza {
	
	@Override
	public String description() {
		return "Pan Pizza";
	}
	
	@Override
	public double cost() {
		return 300.0;
	}
	
}
