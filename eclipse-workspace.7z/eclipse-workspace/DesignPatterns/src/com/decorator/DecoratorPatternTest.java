package com.decorator;

public class DecoratorPatternTest {
	public static void main(String[] args) {
		Pizza panPizza = new PanPizza();
		panPizza = new Tomatoes(new Onions(new Cheese(panPizza)));
		//panPizza = new Onions(panPizza);
		//panPizza = new Cheese(panPizza);
		
		System.out.println("You ordered - Pan Pizza");
		System.out.println("Your total cost " + panPizza.cost());
	}
}
