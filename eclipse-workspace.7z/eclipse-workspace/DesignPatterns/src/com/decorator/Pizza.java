package com.decorator;

public interface Pizza {
	
	public String description();
	public double cost();
}
