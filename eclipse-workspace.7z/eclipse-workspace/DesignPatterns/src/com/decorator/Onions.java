package com.decorator;

public class Onions extends PizzaTopping {
	
	public Onions(Pizza pizza) {
		this.pizza = pizza;
	}
	
	@Override
	public String description() {
		return "Onions";
	}
	
	@Override
	public double cost() {
		return pizza.cost() + 40.0;
	}
	
}
