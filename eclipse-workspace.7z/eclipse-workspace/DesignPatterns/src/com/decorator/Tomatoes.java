package com.decorator;

public class Tomatoes extends PizzaTopping {
	
	public Tomatoes(Pizza pizza) {
		this.pizza = pizza;
	}
	
	@Override
	public String description() {
		return "Tomatoes";
	}
	
	@Override
	public double cost() {
		return pizza.cost() + 50.0;
	}
	
}
