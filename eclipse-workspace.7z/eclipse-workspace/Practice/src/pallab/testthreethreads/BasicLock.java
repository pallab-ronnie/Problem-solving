package pallab.testthreethreads;

public class BasicLock {

	private boolean isNotified = false;
	
	public synchronized void lock() throws InterruptedException{
		while(!isNotified) {
			wait();
		}
		this.isNotified = false;
	}
	
	public synchronized void unlock() {
		this.isNotified = true;
		notify();
			
	}
}
