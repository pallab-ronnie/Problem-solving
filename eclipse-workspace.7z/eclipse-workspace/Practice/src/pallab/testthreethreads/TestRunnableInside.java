package pallab.testthreethreads;

public class TestRunnableInside {

	public static void main(String[] args) {

		Thread t1 = new Thread(new MyThread1() {
			public void run() {
				System.out.println("This is main");
			}
		});
		t1.start();
	}

}
