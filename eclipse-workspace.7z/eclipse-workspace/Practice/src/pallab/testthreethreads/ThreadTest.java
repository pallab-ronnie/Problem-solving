package pallab.testthreethreads;

public class ThreadTest {

	public static void main(String[] args) throws InterruptedException {

		MyThread myThread = new MyThread();
		Thread t1 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					myThread.waitingThread();
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
				
			}
		});
		
		Thread t2 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					myThread.signallingThread();
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
				
			}
		});
		
		Thread t3 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					myThread.signallingThread();
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
				
			}
		});
		
		t1.start();
		t2.start();
		t3.start();
		
		t1.join();
		t2.join();
		t3.join();
		
		myThread.getCount();
	}

}
