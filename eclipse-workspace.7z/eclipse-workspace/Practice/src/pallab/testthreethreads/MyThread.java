package pallab.testthreethreads;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class MyThread {

	private Lock lock = new ReentrantLock();
	private Condition cond = lock.newCondition();
	
	private int count = 0;
	
	private void increment() {
		for(int i = 0; i<10000 ; i++) {
			count++;
		}
	}
	
	public void waitingThread() throws InterruptedException {
		lock.lock();
		System.out.println("Waiting...");
		cond.await();
		try {
			increment();
		}
		finally {
			lock.unlock();
			System.out.println("First thread");
		}
	}
	
	public void signallingThread() throws InterruptedException{
		lock.lock();
		try {
			increment();
		}
		finally {
			cond.signal();
			System.out.println("Sending signal");
			lock.unlock();
			System.out.println("Unlocking done");
			
		}
	}
	
	
	public void getCount() {
		System.out.println(count);
	}
	
	
}
