package pallab.testthreethreads;

public class MyThread1 extends Thread {

	@Override
	public void run() {

		System.out.println("Hi I am run of MyThread");
	}

}
