package pallab.testthreethreads;

import java.util.concurrent.TimeUnit;

public class StopThreadDemo {

	public static void main(String[] args) {
		
		ServerThread serverThread = new ServerThread();
		Thread t1 = new Thread(serverThread);
		
		t1.start();
		
		System.out.println("Stopping the server Thread");
		
		serverThread.stop();
		
		//Thread.sleep(200);
		
		try {
			TimeUnit.MILLISECONDS.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Thread is stopped");

	}

}
