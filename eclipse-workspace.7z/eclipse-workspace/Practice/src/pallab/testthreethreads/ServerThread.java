package pallab.testthreethreads;

public class ServerThread implements Runnable {

	private volatile boolean exit = false;
	
	@Override
	public void run() {
		while(!exit) {
			System.out.println("Server is running");
		}
		
		System.out.println("Server is stopped");
	}
	
	public void stop() {
		this.exit = true;
	}
	
	

}
