package pallab.diningphilosopher;

public class Philosopher implements Runnable {
	Object leftChopStick = new Object();
	Object rightChopStick = new Object();

	public Philosopher(Object leftChopStick, Object rightChopStick) {
		super();
		this.leftChopStick = leftChopStick;
		this.rightChopStick = rightChopStick;
	}

	private void doAction(String action) throws InterruptedException{
		System.out.println(Thread.currentThread().getName() + ": " +action);
		Thread.sleep(2000);
	}

	@Override
	public void run() {

		try {
			while(true) {
				doAction("Thinking");
				synchronized (leftChopStick) {
					doAction("Picked up left chopstick");
					synchronized (rightChopStick) {
						doAction("Picked up right chopstick - eating" );

						doAction("Put down right chopstick");
					}
					doAction("Put Down left chopStick. Back to thinking...");
				}	
			}
		}catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return;
		}
	}

}
