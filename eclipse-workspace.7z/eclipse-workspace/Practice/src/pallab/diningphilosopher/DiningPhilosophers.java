package pallab.diningphilosopher;

public class DiningPhilosophers {

	public static void main(String[] args) {

		Philosopher philosopher[] = new Philosopher[5];
		Object chopSticks[] = new Object[philosopher.length];
		
		for(int i=0 ; i<chopSticks.length ; i++) {
			chopSticks[i] = new Object();
		}
		for(int i = 0; i<philosopher.length ; i++) {
			Object leftChopStick = chopSticks[i];
			Object rightChopStick = chopSticks[(i+1)%chopSticks.length];
			if(i== philosopher.length -1) {
				philosopher[i] = new Philosopher(rightChopStick, leftChopStick);
			}
			else {
				philosopher[i] = new Philosopher(leftChopStick, rightChopStick);
			}
			Thread t = new Thread(philosopher[i], "Philosopher " + (i+1));
			t.start();
		}
	}

}
