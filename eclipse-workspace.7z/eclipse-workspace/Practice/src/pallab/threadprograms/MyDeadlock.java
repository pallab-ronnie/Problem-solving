package pallab.threadprograms;

public class MyDeadlock {

	String str1 = "Java";
	String str2 = "UNIX";
	static int count = 0;
	
	Thread t1 = new Thread() {
		@Override
		public void run() {
			while(true) {
				synchronized (str1) {
					synchronized (str2) {
						System.out.println(str1 + str2);
						System.out.println(++count);
					}
				}
			}
		}
	};
	
	Thread t2 = new Thread() {
		@Override
		public void run() {
			while(true) {
				synchronized (str2) {
					synchronized (str1) {
						System.out.println(str1 + str2);
						System.out.println(++count);
					}
				}
			}
		}
	};
	
	public static void main(String[] args) {
		MyDeadlock myDeadlock = new MyDeadlock();
		myDeadlock.t1.start();
		myDeadlock.t2.start();
	}

}
