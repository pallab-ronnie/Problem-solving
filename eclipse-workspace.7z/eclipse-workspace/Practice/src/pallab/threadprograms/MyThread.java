package pallab.threadprograms;

public class MyThread implements Runnable {

	@Override
	public void run() {
		try {
			Thread.sleep(3);
			System.out.println("Thread : " + Thread.currentThread().getName());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
