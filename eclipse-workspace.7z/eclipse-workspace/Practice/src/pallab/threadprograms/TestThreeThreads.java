package pallab.threadprograms;

import java.lang.Thread.State;

import sun.misc.Lock;

public class TestThreeThreads {

	public static void main(String[] args) throws InterruptedException {

		MyThread myThread = new MyThread();
		Thread t1 = new Thread(myThread);
		Thread t2 = new Thread(myThread);
		Thread t3 = new Thread(myThread);
		
		Object obj1 = new Lock();
		
		//t1.start();
		//t2.start();
		//t3.start();
		
		synchronized (obj1) {
			try {
				while(!(t1.getState().equals(State.TERMINATED) && t2.getState().equals(State.TERMINATED))) {
					t3.wait();
				}
				t3.start();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
		
		synchronized (obj1) {
			t1.start();
			t2.start();
			while(t1.getState().equals(State.TERMINATED) && t2.getState().equals(State.TERMINATED)) {
				t1.notify();
				t2.notify();
			}
		}
	}

}
