package pallab.threadprograms;

public class OddEvenPrinter {

	boolean odd;
	int MAX = 100;
	int count =1 ;

	public void printOdd() {
		synchronized (this) {
			while(count<MAX) {
				while(!odd) {
					try {
						wait();
					} catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println("I am odd " + count);
				count ++;
				odd = false;
				notify();
			}
		}
	}

	public void printEven() {
		synchronized (this) {
			while(count<MAX) {
				while(odd) {
					try {
						wait();
					} catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
				System.out.println("I am even " + count);
				count ++;
				odd = true;
				notify();
			}
		}
	}

	public static void main(String args[]) {
		OddEvenPrinter oddEvenPrinter = new OddEvenPrinter();
		oddEvenPrinter.odd = true;

		/*Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				oddEvenPrinter.printEven();

			}
		});*/

		/*Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				oddEvenPrinter.printOdd();

			}
		});*/

		Thread t1 = new Thread(() -> oddEvenPrinter.printEven());
		Thread t2 = new Thread(() -> oddEvenPrinter.printOdd());

		t1.start();
		t2.start();
	}

}
