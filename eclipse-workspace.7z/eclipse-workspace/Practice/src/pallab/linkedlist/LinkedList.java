package pallab.linkedlist;

public class LinkedList {
	
	Node start;
	Node end;
	int size;
	
	public LinkedList(){
		start = null;
		end = null;
		size = 0;
	}
	
	public boolean isEmpty() {
		return start == null;
	}
	
	public int size() {
		return size;
	}
	
	public void insertAtStart(int val) {
		Node node = new Node(val, null);
		size++;
		if(start==null) {
			start = node;
			end = start;
		}
		
		else {
			node.setLink(start);
			start = node;
		}
	}
	
	public void insertAtEnd(int val) {
		Node node = new Node(val, null);
		size++;
		if(start==null) {
			start = node;
			end = start;
		}
		
		else {
			end.setLink(node);
			end = node;
		}
	}
	
	public void insertAtPos(int val, int pos) {
		Node node = new Node(val, null);
		size++;
		
		Node ptr = start;
		pos = pos - 1;
		for (int i=1; i<size; i++) {
			if(i==pos) {
				Node tmp = ptr.getLink();
				ptr.setLink(node);
				node.setLink(tmp);
				break;
			}
			ptr = ptr.getLink();
		}
	}
	
	public void deleteAtPos(int pos) {
		if(pos==1) {
			start = start.getLink();
			size --;
			return;
		}
		
		if(pos == size) {
			Node t = start;
			Node s = start;
			
			while(s!= end) {
				t=s;
				s = s.getLink();
			}
			end = t;
			end.setLink(null);
			size --;
			return;
		}
		
		Node ptr = start;
		pos = pos-1;
		for(int i = 1;i<size - 1; i++) {
			if(i==pos) {
				Node tmp = ptr.getLink();
				tmp = tmp.getLink();
				ptr.setLink(tmp);
			}
			ptr = ptr.getLink();
			
		}
		size --;
	}
	
	public void display() {
		if(size == 0) {
			System.out.println("List is empty\n");
			return;
		}
		if(start.getLink() == null) {
			System.out.println("Data " + start.getData());
			return;
		}
		
		Node ptr = start;
		System.out.println(start.getData());
		ptr = start.getLink();
		while(ptr.getLink()!=null) {
			System.out.println(ptr.getData());
			ptr = ptr.getLink();
		}
		System.out.println(ptr.getData());
		
	}
	
	 
}
