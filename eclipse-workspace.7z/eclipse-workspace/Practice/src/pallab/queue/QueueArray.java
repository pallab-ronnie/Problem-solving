package pallab.queue;

public class QueueArray {

	protected int arr[];
	protected int front, rear, size, length;

	public QueueArray(int n) {
		size = n;
		length = 0;
		arr = new int[size];
		front = -1;
		rear = -1;
	}
	
	public boolean isFull() {
		return front ==0 && rear == size-1;
	}
	
	public boolean isEmpty() {
		return front == -1;
	}
	
	public int getSize() {
		return length;
	}
	
	public void insert(int val) {
		if(rear==-1) {
			front = 0;
			rear = 0;
			arr[rear] = val;
		}
		
		else if(rear +1 >= size) {
			throw new IndexOutOfBoundsException();
		}
		else {
			arr[++rear] = val;
		}
		length++;
	}
	
	public int delete() {
		length--;
		int ele = arr[front];
		if(front == rear) {
			front = -1;
			rear = -1;
		}
		else {
			front ++;
		}
		return ele;
	}
}
