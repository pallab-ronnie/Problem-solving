package pallab.queue;

import java.util.Stack;

public class QueueUsingStack {

	Stack<Integer> s;
	Stack<Integer> tmp;
	
	QueueUsingStack(){
		s = new Stack<Integer>();
		tmp = new Stack<>();
	}
	
	public void insert(int val) {
		if(s.size() == 0) {
			s.push(val);
		}
		else {
			int l = s.size();
			for(int i = 0;i<l ;i++) {
				tmp.push(s.pop());
			}
			s.push(val);
			for(int i = 0; i<l;i++) {
				s.push(tmp.pop());
			}
		}
	}
	
	public int remove() {
		return s.pop();
	}
}
