package pallab.serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationDemo {

	public static void main(String[] args) throws IOException {

		Employee emp = new Employee(1081402, "Pallab" , "Bangalore");
		String filename = "emp.ser";
		//Serialize
		FileOutputStream fileOutputStream = null;
		ObjectOutputStream objectOutputStream = null;
		try {
			fileOutputStream = new FileOutputStream(filename);
			objectOutputStream  = new ObjectOutputStream(fileOutputStream);

			objectOutputStream.writeObject(emp);

		}catch(IOException e) {
			e.printStackTrace();
		} finally {
			fileOutputStream.close();
			objectOutputStream.close();
		}

		//De-serialize
		Employee emp1 = null;
		try {
			FileInputStream file = new FileInputStream(filename);
			ObjectInputStream obj = new ObjectInputStream(file);
			emp1 = (Employee)obj.readObject();
			System.out.println(emp1.toString());
			file.close();
			obj.close();
		}catch(IOException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
