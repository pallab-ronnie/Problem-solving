package pallab.inner;

public class A {

	class B{
		int i;
	}
	
	static class C{
		int i;
	}
	public static void main(String[] args) {
		A obj = new A();
		A.B b = obj.new B();
		A.C c = new A.C();
		A.B b1 = new A.B();
	}
}
