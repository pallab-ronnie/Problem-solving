package pallab.practice;

public class Empl {

	private String name = "Pallab";
}
