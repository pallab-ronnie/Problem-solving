package pallab.practice;

class A{
	String s;
	public int test() {
		static int i = 0;
		return i;
	}
}
public class PrintTest2 {

	
}
