package pallab.practice;

import java.util.Scanner;

public class RemoveWhiteSpaces {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		String s = scanner.nextLine();
		System.out.println(s);
		//System.out.println(s.replaceAll("\\s", ""));
		
		char[] strArr = s.toCharArray();
		StringBuffer strBuffer = new StringBuffer();
		
		for(int i=0; i<strArr.length; i++) {
			if((strArr[i] != ' ') && (strArr[i] !='\t')) {
				strBuffer.append(strArr[i]);
			}
		}
		
		String result = strBuffer.toString();
		System.out.println(result);
	}
}
