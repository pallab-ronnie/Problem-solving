package pallab.practice;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String args[]) {
		int number = new Scanner(System.in).nextInt();
		System.out.println("Fibonacci series upto " + number + " is : ");
		Object obj;
		for(int i=1; i<=number; i ++) {
			System.out.println(fibonacci(i) + " ");
		}
	}

	private static int  fibonacci(int n) {
		if (n==1 || n==2) {
			return 1;
		}
		
		return fibonacci(n-1) + fibonacci(n-2);
	}
}
