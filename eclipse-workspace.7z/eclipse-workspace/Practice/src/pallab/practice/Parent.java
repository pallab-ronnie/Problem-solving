package pallab.practice;

 class Parent {
static void check() {
	System.out.println("Parent");
}
}

class Child extends Parent{
	static void test() {
		System.out.println("child");
	}
	
	public static void main(String kjdshv[]) {
		Parent p = new Child();
		p.test
	}
}