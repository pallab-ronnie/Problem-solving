package pallab.practice;


class TestPrinter{
	int i;
	boolean isFalse;
	static int j;
	
	public void printVariable() {
		System.out.println(i);
		System.out.println(isFalse);
		System.out.println(j);
	}
}

public class PrintTest3 {

	public static void main(String[] args) {
		TestPrinter t = new TestPrinter();
		t.printVariable();
	}
}
