package pallab.practice;

public class StringPattern {
	
	public static void main(String[] args) {

		String data = "Apple     IBM TCS CTS";
		String companies1[] = data.split("\\s+");
		
		for(String str: companies1) {
			System.out.println(str);
		}
		
		//only num
		
		String data1 = "Apple.123IBM.456TCS.789CTS";
		System.out.println(data1.replaceAll("\\D", ""));
		System.out.println(data1.replaceAll("[^0-9]+", ""));
		//all alphabete 
		System.out.println(data1.replaceAll("[^a-zA-Z]+", ""));
		
		//Check if a String has only numbers
		String num = "1234567";
		String regex = "[0-9]+";
		System.out.println(num.matches(regex));
		
		}
	
}
