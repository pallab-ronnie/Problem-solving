package pallab.practice;

import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;

public class TestCollection {

	public static void main(String[] args) {

		Collections c ;
		
		CountDownLatch c1;
		
		LinkedList l;
		
		HashMap h;
	}

}
