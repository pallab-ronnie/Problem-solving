package pallab.practice;

import java.util.concurrent.atomic.AtomicInteger;

public class OddEven {

	public static void main(String[] args) {
		
		AtomicInteger sharedVar =new AtomicInteger(1);
		Thread  t1 = new Thread(new Even(sharedVar));
		Thread t2 = new Thread(new Odd(sharedVar));
		t1.start();
		t2.start();
	}
}

class Odd implements Runnable{

	AtomicInteger sharedVar ;
	
	
	public Odd(AtomicInteger sharedVar) {
		this.sharedVar = sharedVar;
	}


	@Override
	public void run() {
		while(true) {
			try {
				printOdd();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public void printOdd() throws InterruptedException {
		
		synchronized (sharedVar) {
			while(sharedVar.get()%2==0) {
				sharedVar.wait();
			}
			System.out.println(sharedVar);
			sharedVar.incrementAndGet();
			sharedVar.notify();
		}
		
	}
}

class Even implements Runnable{
	
	AtomicInteger sharedVar;
	 
     	
	public Even(AtomicInteger sharedVar) {
		this.sharedVar = sharedVar;
	}



	@Override
	public void run() {

		while(true) {
		try {
			printEven();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		}
	}
	
	public void printEven() throws InterruptedException {
		
		synchronized (sharedVar) {
			while(sharedVar.get()%2!=0) {
				sharedVar.wait();
			}
			System.out.println(sharedVar);
			sharedVar.incrementAndGet();
			sharedVar.notify();
		}
		
	
	}
}