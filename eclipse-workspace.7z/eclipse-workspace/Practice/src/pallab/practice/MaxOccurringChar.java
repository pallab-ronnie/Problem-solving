package pallab.practice;

public class MaxOccurringChar {

	
	static char count[] = new char[256];
	public static void main(String[] args) {
		String str = "aabbbbbbbbccbbaaaa";
		getMaxOccurring(str);

	}

	private static void getMaxOccurring(String str) {

		getCountArr(str);
		int max = -1;
		char result = ' ';
		int index = -1;
		
		for(int i =0 ;i< str.length(); i++) {
			if(max < count[str.charAt(i)]) {
				max = count[str.charAt(i)];
				result = str.charAt(i);
				index = i;
			}
				
		}
		System.out.println("Char " + result);
		System.out.println("count " + max);
		System.out.println("Index " + index);
	}

	private static void getCountArr(String str) {

		for(int i=0 ;i <str.length(); i++) {
			count[str.charAt(i)]++;
		}
	}

}
