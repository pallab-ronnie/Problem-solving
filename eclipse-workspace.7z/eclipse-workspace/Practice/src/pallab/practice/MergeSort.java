package pallab.practice;

import java.util.Scanner;

public class MergeSort {

	public static void sort(int arr[], int low, int high) {
		int n = high - low;
		if(n<=1) {
			return;
		}
		int mid = low + n/2;
		
		sort(arr, low, mid);
		sort(arr, mid, high);
		
		//Merge
		int temp[] = new int[n];
		int i = low, j = mid;
		
		for(int k = 0; k<n ; k++) {
			if(i == mid) {
				temp[k] = arr[j++];
			}
			else if(j == high) {
				temp[k] = arr[i++];
			}
			else if(arr[j]<arr[i]) {
				temp[k] = arr[j++];
			}
			else {
				temp[k] = arr[i++];
			}
			
		}
		
		for(int k=0; k< n; k++) {
			arr[low+k] = temp[k];
		}
	}
	public static void main(String[] args) {
		
		Scanner scan = new Scanner( System.in );        
        System.out.println("Merge Sort Test\n");
        int n, i;
        /* Accept number of elements */
        System.out.println("Enter number of integer elements");
        n = scan.nextInt();
        /* Create array of n elements */
        int arr[] = new int[ n ];
        /* Accept elements */
        System.out.println("\nEnter "+ n +" integer elements");
        for (i = 0; i < n; i++)
            arr[i] = scan.nextInt();
        /* Call method sort */
        sort(arr, 0, n);
        /* Print sorted Array */
        System.out.println("\nElements after sorting ");        
        for (i = 0; i < n; i++)
            System.out.print(arr[i]+" ");            
        System.out.println();         
	}

}
