package pallab.practice;

 class Hello1 {

	int x;
	Hello1(int x){
		this.x = x;
	}
	
	public Object clone() {
		Hello1 h = new Hello1(this.x);
		return h;
	}
	
	public String toString() {
		return " "+x;
	}
	
}
public class Hello{
	public static void main(String[] args) {
		Hello1 h = new Hello1(56);
		System.out.println(h.clone());
	}
		
		
	}


