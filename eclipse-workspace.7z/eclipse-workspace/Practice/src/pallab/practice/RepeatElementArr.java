package pallab.practice;

public class RepeatElementArr {

	public static void main(String[] args) {
		int[] arr = {4,2,5,6,4,5};
		getRepeatingEle(arr, arr.length);
	}

	private static void getRepeatingEle(int[] arr, int length) {

		int count[] = new int[256];
		for(int i=0 ; i<length; i++) {
			if(count[arr[i]] == 1) {
				System.out.println("Duplicate " + arr[i]);
			}
			else {
				count[arr[i]] ++;
			}
		}
	}

}
