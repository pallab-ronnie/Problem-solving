package pallab.practice;

public class TestCharArr {

	public static void main(String[] args) {

		char[] arr = new char[256];
		int i = ++arr['a'];
		//System.out.println(i);
		char c = '\u0000';
		System.out.println((int)c);
	}

}
