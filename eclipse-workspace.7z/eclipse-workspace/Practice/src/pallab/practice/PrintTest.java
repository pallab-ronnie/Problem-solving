package pallab.practice;

public class PrintTest {

	public static void main(String[] args) {
		int a = 5;
		int b = 6;
		String c = "7";
		System.out.println(a + b + c);
	}
}
