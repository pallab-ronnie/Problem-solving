package pallab.practice;

public class StringReverse {

	public static void main(String[] args) {
		String s = "Pallab";
		char in[] = s.toCharArray();
		int begin = 0;
		int end = in.length -1;
		while(begin<end) {
			char tmp = in[begin];
			in[begin] = in[end];
			in[end] = tmp;
			begin ++;
			end --;
		}
		
		System.out.println(in);

	}

}
