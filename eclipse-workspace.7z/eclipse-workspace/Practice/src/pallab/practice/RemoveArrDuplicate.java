package pallab.practice;

class RemoveArrDuplicate
{
    // Function to remove duplicate elements
    // This function returns new size of modified
    // array.
    
     
    public static void main (String[] args) 
    {
        int arr[] = {1, 2, 2, 3, 4, 4, 4, 5, 5};
        int n = arr.length;
         
        n = removeDuplicates(arr, n);
  
        // Print updated array
        for (int i=0; i<n; i++)
           System.out.print(arr[i]+" ");
    }

	private static int removeDuplicates(int[] arr, int n) {
		if(n==0 || n==1) {
			return n;
		}
		int j = 0;
		for(int i=0;i<n-1;i++) {
			if(arr[i] != arr[i+1]) {
				arr[j++] = arr[i];
			}
		}
		arr[j++] = arr[n-1];
		return j;
	}

	/*private static int removeDuplicates(int[] arr, int n) {
		if(n==0 || n==1) {
			return n;
		}
		
		int tmp[] = new int[n];
		int j = 0;
		for(int i=0; i<n-1;i++) {
			if (arr[i]!=arr[i+1]) {
				tmp[j++] = arr[i];
			}
		}
		tmp[j++] = arr[n-1];
		
		for (int i=0; i<j; i++) {
			arr[i] = tmp[i];
		}
		return j;
	}*/
    
}
 