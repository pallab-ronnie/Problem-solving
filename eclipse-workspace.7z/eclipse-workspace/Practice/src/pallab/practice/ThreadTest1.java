package pallab.practice;

class AThread extends Thread {
	public void run() {
		for(int i = 0; i<2 ; i++) {
			System.out.println(i);
		}
	}
}

class BTest{
	public void check(AThread a) {
		a.start();
	}
}

public class ThreadTest1 {
	public static void main(String[] args) {
		BTest b = new BTest();
		b.check(new AThread() {} );
	}
}
