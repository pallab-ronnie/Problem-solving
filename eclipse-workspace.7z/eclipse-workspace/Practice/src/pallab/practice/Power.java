package pallab.practice;

public class Power {

	public static void main(String[] args) {

		int num = 5;
		int pow = 2;
		int f = 1;
		for(int i=1; i<=pow; i++ ) {
			f = f*num;
		}
		System.out.println(f);
	}

}
