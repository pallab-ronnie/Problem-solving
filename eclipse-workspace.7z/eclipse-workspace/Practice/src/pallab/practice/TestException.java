package pallab.practice;

public class TestException {

	public static void main(String[] args) throws RuntimeException, Exception {

		try {
			
			throw new RuntimeException();
		}catch(RuntimeException e) {
			System.out.println("Runtime exception");
		//	throw new RuntimeException();
		} 
		catch(Exception e) {
			System.out.println("Exception");
		}
//		finally {
//			try {
//			throw new Exception();
//			} catch(Exception e) {
//				
//			}
//		}
	}

}
