package pallab.practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class HitAndTrial {
       public static void main(String[] args) throws FileNotFoundException, IOException, ParseException {
              String current = "C:\\Users\\502552182\\test123\\etymo_output";
              String session_cfg = "etymo.json";
              String abc =  "features\\design\\";
              File out_dir = new File(current +"\\" + "etymo_output\\");
              out_dir.mkdirs();
              JSONParser jp = new JSONParser();
              Object ob = jp.parse(new FileReader(current+ "\\" +session_cfg));
              JSONObject jo = (JSONObject)ob;
              jo.put("logerror", false);
              jo.put("workspacepath", current);
              jo.put("alm_test_sets", false);
              jo.put("alm_test_runs", false);
              jo.put("testresultfile", "");
              jo.put("alm_update_reqs", true);
              jo.put("alm_test_cases", true);
              jo.put("alm_writeback", true);
              jo.put("alm_register_reqs", true);
              String path = current + "\\" + abc;
              System.out.println(path);
              jo.put("startingdirectory", path);
              System.out.println(jo.get("startingdirectory"));
              FileWriter fw =new FileWriter(current +"\\" + "etymo_output\\" + session_cfg);
         fw.write(jo.toString());
         System.out.println(jo.toString());
         fw.flush();
         fw.close();
       }
}

