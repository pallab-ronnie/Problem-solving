package pallab.practice;

public class TestBasicJavaSysout {

	static {
		System.out.println("this is static block");
	}
	{
		System.out.println("this is normal block");
	}
	public static void main(String[] args) {

		System.out.println("This is main");
	}

}
