package pallab.practice;

public class TestException1 {

	
	int ab=0;
	public static void main(String[] args) {

		int a = 2;
		int b = 0;
		String s = null;
		try {
			s.length();
			int c = a/b;
		}catch(ArithmeticException e) {
			System.out.println("Arithmatic");
		}catch(NullPointerException e) {
			System.out.println("Null");
		}
	}

}
