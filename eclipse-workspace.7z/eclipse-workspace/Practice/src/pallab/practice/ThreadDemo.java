package pallab.practice;



//class A{}
//class B extends A{}
//class C extends B{}

class big extends Thread{
	public big(Runnable ren) {
		super(ren);
	}
	public void run() {
		System.out.println("big");
	}
}

class small extends Thread{
	public void run() {
		System.out.println("small");
	}
}
public class ThreadDemo extends Thread {

	public static void main(String[] args) {
try {
		ThreadDemo A = new ThreadDemo();
		A.start();
		A.run();
		A.start();
		A.wait();
	
}catch(Exception s) {
	System.out.println(s);
}
}
	public void start() {
		System.out.println("start");
	}
	
	public void run() {
		System.out.println("inside run");
		for(int i = 0;i<5;i++) {
			System.out.println(i);
		}
	}
}
