package pallab.practice;

public class Reverse {

	public static void main(String[] args) {

		int number = 1234;
		int sum = 0;
		int rem;
		
		while(number>0) {
			rem = number%10;
			sum = (sum*10) + rem;
			number = number/10;
		}
		System.out.println(sum);
	}

}
