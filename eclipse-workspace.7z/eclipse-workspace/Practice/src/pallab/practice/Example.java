package pallab.practice;

public class Example {
	int i=9;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 10;
		{
			int i=100;
			System.out.println(i);
		}
	}

}
