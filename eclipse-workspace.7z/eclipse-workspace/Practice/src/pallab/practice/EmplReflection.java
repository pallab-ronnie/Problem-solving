package pallab.practice;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public class EmplReflection {

	public static void main(String[] args) {

		try {
			Class c = Class.forName(Empl.class.getName());
			Constructor[] con = c.getConstructors();
			System.out.println(con.length);
			Field[] field = c.getFields();
			System.out.println(field.length);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
