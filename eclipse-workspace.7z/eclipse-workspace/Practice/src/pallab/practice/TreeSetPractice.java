package pallab.practice;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetPractice {

	public static void main(String[] args) {

		TreeSet t = new TreeSet();
		t.add("one");
		t.add("two");
		t.add("three");
		t.add("one");
		
		Iterator it = t.iterator();
		while(it.hasNext()){
			System.out.println(it.next() + " ");
		}
	}

}
