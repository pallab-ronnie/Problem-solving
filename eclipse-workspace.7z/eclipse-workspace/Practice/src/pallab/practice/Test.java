package pallab.practice;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NavigableSet;
import java.util.TreeSet;

 class Test {
	 
public static void main(String kjsachc[]) {
	List<Integer> l = new ArrayList<>();
	l.add(100);
	l.add(1);
	l.add(1000);
	l.add(10);
	l.add(10000);
	l.add(10);
	
	NavigableSet<Integer> n = new TreeSet(l);
	System.out.println(n.tailSet(10, false));
	System.out.println(n.tailSet(10));
	System.out.println(n.higher(10));
	int A = n.pollFirst();
	System.out.println(n.size());
 	
}
	 
}