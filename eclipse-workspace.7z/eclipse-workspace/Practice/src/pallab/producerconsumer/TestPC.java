package pallab.producerconsumer;

import java.util.LinkedList;
import java.util.Queue;

public class TestPC {

	public static void main(String args[]) {
		Queue<Integer> queue = new LinkedList<>();
		int maxSize = 10;
		Thread prod = new Producer(queue, maxSize, "PRODUCER");
		Thread cons = new Consumer(queue, maxSize, "CONSUMER");
		
		prod.start();
		cons.start();
	}
}
