package com.mainthreadjoin;

public class MyThread implements Runnable {

	public static Thread currentThread = null;
	@Override
	public void run() {
		
			try {
				currentThread.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("This is mythread");
			
		
		
	}

}
