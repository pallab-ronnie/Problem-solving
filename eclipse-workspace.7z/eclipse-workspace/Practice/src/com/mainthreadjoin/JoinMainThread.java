package com.mainthreadjoin;

public class JoinMainThread {

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		myThread.currentThread = Thread.currentThread();
		Thread t1 = new Thread(myThread);
		t1.start();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("This is main");
	}
}
