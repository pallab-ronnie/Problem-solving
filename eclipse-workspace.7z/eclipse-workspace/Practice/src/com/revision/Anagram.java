package com.revision;

import java.util.HashMap;
import java.util.Map;

public class Anagram {
	
	public static void main(String[] args) {

		String str1 = "ABC";
		String str2 = "BCA";
		
		if(isAnagram(str1,str2)) {
			System.out.println("Anagram");
		}
		else {
			System.out.println("Not anagram");
		}
	}
	
	public static boolean isAnagram(String str1, String str2) {
		
		if(str1.length() != str2.length()) {
			return false;
		}
		
		Map<Character, Integer> countMap = new HashMap<>();
		int charCount = 0;
		for(int i=0 ;i<str1.length() ;i++) {
			if(countMap.containsKey(str1.charAt(i))) {
				charCount = countMap.get(str1.charAt(i));
			}
			
			countMap.put(str1.charAt(i), ++charCount);
			
			charCount=0;
			
			if(countMap.containsKey(str2.charAt(i))) {
				charCount = countMap.get(str2.charAt(i));
			}
			
			countMap.put(str2.charAt(i), --charCount);
		}
		
		for(Integer i: countMap.values()) {
			if(i!=0) {
				return false;
			}
		}
		
		return true;
	}
	
}
