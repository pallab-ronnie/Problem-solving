package com.revision;

import java.util.LinkedList;
import java.util.Queue;

public class ProdConClient {

	public static void main(String[] args) {
		Queue<Integer> queue = new LinkedList<>();
		Thread t1 = new Thread(() -> new Producer(queue, 10).produce());
		Thread t2 = new Thread(() -> new Consumer(queue, 10).consume());
		t1.start();
		t2.start();
	}
}
