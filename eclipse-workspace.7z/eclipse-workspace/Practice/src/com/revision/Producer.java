package com.revision;

import java.util.Queue;
import java.util.Random;

public class Producer {

	private Queue<Integer> queue;
	private int MAX;
	public Producer(Queue<Integer> queue, int mAX) {
		super();
		this.queue = queue;
		MAX = mAX;
	}

	public void produce() {
		while(true) {
			synchronized (queue) {

				while(queue.size()==MAX) {
					try {
						queue.wait();
						
					} catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				
				int i = new Random().nextInt();
				System.out.println("Producing " + i);
				queue.add(i);
				queue.notify();
				
			}
		}
	}
}

