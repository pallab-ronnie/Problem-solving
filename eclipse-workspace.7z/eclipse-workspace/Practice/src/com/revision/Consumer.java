package com.revision;

import java.util.Queue;
import java.util.Random;

public class Consumer {

	private Queue<Integer> queue;
	private int MAX;
	public Consumer(Queue<Integer> queue, int mAX) {
		super();
		this.queue = queue;
		MAX = mAX;
	}
	
	public void consume() {
		while(true) {
			synchronized (queue) {

				while(queue.isEmpty()) {
					try {
						queue.wait();
						
					} catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				System.out.println(queue.remove());
				queue.notify();
			}
		}
	}
}
