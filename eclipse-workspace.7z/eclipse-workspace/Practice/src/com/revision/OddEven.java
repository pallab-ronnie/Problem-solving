package com.revision;

public class OddEven {

	boolean isOdd;
	int count = 1;
	
	public void printOdd() {
		while(count < 100) {
			synchronized (this) {
				while(!isOdd) {
					try {
						wait();
					} catch(InterruptedException e) {
						e.printStackTrace();
						
					}
				}
				System.out.println(count);
				count ++;
				notify();
			}
		}
	}
	
	public void printEven() {
		while(count < 100) {
			synchronized (this) {
				while(isOdd) {
					try {
						wait();
					} catch(InterruptedException e) {
						e.printStackTrace();
						
					}
				}
				System.out.println(count);
				count ++;
				notify();
			}
		}
	}
	
	public static void main(String[] args) {
		OddEven oddEven = new OddEven();
		oddEven.isOdd = true;
		Thread t1 = new Thread(() -> oddEven.printOdd());
		Thread t2 = new Thread(() -> oddEven.printEven());
		
		t1.start();
		t2.start();
	}
}
