package com.generics;

public class TestSubType<T extends A & C & B> {
	
	
}
