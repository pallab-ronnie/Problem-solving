package com.generics;

public interface C {
	
}
