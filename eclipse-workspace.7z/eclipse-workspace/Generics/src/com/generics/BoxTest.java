package com.generics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BoxTest {
	
	public static void main(String[] args) {

		Box<String> box = new Box<>();
		box.setObject("a String");
		box.inspect(123);
		
		sumListOfNumbers(Arrays.asList(1,2,3));
	}
	
	public static void sumListOfNumbers(List<? extends Number> list) {
		double d = 0.0;
		for(Number n: list) {
			d += n.doubleValue();
		}
		
		System.out.println("sum " + d);
	}
	
	public static void testInheritance() {
		List<Base> baseList = new ArrayList<>();
		List<Sub> subList = new ArrayList<>();
		
		Base b = new Base();
		Sub s = new Sub();
		
		baseList.add(b);
		baseList.add(s);
		
		subList.add(s);
	}
}
