package com.generics;

public class A {
	
}
