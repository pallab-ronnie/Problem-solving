package com.generics;

import java.util.ArrayList;

class Container<T extends Number>{
	T value;

	public void show() {
		System.out.println(value.getClass().getName());
	}
	
	public T getValue() {
		return value;
	}

	public void setValue(T value) {
		this.value = value;
	}
	
	public void demo(ArrayList<? extends T> arr) {
		
	}
	
	public void demo1(ArrayList<? super T> arr) {
		
	}
	
}

public class GenericsDemo {

	public static void main(String[] args) {
		
		Container<Integer> container = new Container<Integer>();
		container.setValue(9);
		container.show();
		container.demo(new ArrayList<Integer>());
		container.demo1(new ArrayList<Number>());
	}

}
