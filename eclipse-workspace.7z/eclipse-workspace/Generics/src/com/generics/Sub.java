package com.generics;

public class Sub extends Base{
	
}
