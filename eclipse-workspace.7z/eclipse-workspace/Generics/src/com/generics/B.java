package com.generics;

public interface B {
	
}
