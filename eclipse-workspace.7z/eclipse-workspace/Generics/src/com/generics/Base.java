package com.generics;

public class Base {
	
}
