package com.practice.BST;

public class BinarySearchTree {
	
	class Node{
		int key;
		Node left, right;
		
		public Node(int key){
			left = right = null;
			this.key = key;
		}
	}
	
	Node root;
	
	public BinarySearchTree() {
		root = null;
	}
	
	public void insert(int key) {
		root = insertRec(root,key);
	}
	
	private Node insertRec(Node root, int key) {
		
		if(root==null) {
			root = new Node(key);
			return root;
		}
		
		if(key < root.key) {
			root.left = insertRec(root.left, key);
		}
		else if(key > root.key) {
			root.right = insertRec(root.right, key);
		}
		
		return root;
	}
	
	public void inOrder() {
		inOrderRec(root);
	}
	
	private void inOrderRec(Node root) {
		if(root != null) {
			inOrderRec(root.left);
			System.out.println(root.key);
			inOrderRec(root.right);
		}
		
	}
	
	public void preOrder() {
		preOrderRec(root);
	}
	
	private void preOrderRec(Node root) {
		if(root != null) {
			System.out.println(root.key);
			preOrderRec(root.left);
			preOrderRec(root.right);
		}
	}
	
	public void postOrder() {
		postOrderRec(root);
	}
	
	private void postOrderRec(Node root) {
		
		if(root != null) {
			postOrderRec(root.left);
			postOrderRec(root.right);
			System.out.println(root.key);
		}
	}
	
	//Delete a node from binary search tree
	
	public void deleteKey(int key) {
		root = deleteRec(root, key);
		
	}
	
	public  Node deleteRec(Node root, int key) {
		if(root == null) {
			return root;
		}
		
		if(key < root.key) {
			root.left = deleteRec(root.left, key);
		}
		else if(key > root.key) {
			root.right = deleteRec(root.right, key);
		}
		else {
			if(root.left == null) {
				return root.right;
			}
			else if(root.right == null) {
				return root.left;
			}
			
			root.key = findMin(root.right);
			root.right = deleteRec(root.right, root.key);
		}
		
		return root;
	}
	
	private int findMin(Node root) {
		while(root.left != null) {
			root = root.left;
		}
		return root.key;
	}

	//Height of a binary search tree
	public int height(Node root) {
		if(root == null) {
			return 0;
		}
		else {
			int lHeight = height(root.left);
			int rHeight = height(root.right);
			
			if(lHeight > rHeight) {
				return 1 + lHeight;
			}
			else {
				return 1 + rHeight;
			}
		}
	}
	
	//Diameter of a binary tree
	public int diameter(Node root) {
		if(root == null) {
			return 0;
		}
		
			int lHeight = height(root.left);
			int rHeight = height(root.right);
			
			int lDiameter = diameter(root.left);
			int rDiameter = diameter(root.right);
			
			return Math.max(lHeight + rHeight +1 , Math.max(lDiameter, rDiameter));
		
	}
	
	//Diameter of a binary tree optimized.
	//Start of diameter opt
	public int diameterOpt(Node root) {
		if(root == null) {
			return 0;
		}
		int ans = Integer.MIN_VALUE;
		int height = heightOpt(root, ans);
		return ans;
	}
	
	public  int heightOpt(Node root, int ans) {
		if(root == null) {
			return 0;
		}
		
		int lHeight = heightOpt(root.left, ans);
		int rHeight = heightOpt(root.right, ans);
		
		ans = Math.max(ans, lHeight + rHeight + 1);
		
		return Math.max(lHeight, rHeight) + 1;
	}
	//End of diameter opt.

	public static void main(String[] args) {
		BinarySearchTree tree = new BinarySearchTree();
		
		tree.insert(50);
		tree.insert(30);
		tree.insert(20);
		tree.insert(40);
		tree.insert(70);
		tree.insert(60);
		tree.insert(80);
		
		System.out.println("Inorder ");
		tree.inOrder();
		System.out.println("Preorder ");
		tree.preOrder();
		System.out.println("Postorder ");
		tree.postOrder();
		
		System.out.println("Delete node");
		tree.deleteKey(20);
		System.out.println("Inorder");
		tree.inOrder();
		
		System.out.println("Delete node");
		tree.deleteKey(50);
		System.out.println("Inorder");
		tree.inOrder();
		
	}
	
	
	
	
}
